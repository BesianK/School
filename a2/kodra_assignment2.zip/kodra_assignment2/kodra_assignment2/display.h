// Besian Kodra || ITDEV-154 || Assignment 2
#pragma once
class display
{
public:
	display();
	~display();
	void getNumber();
	int number;
	void displayResults();
	void goodbye();
};

