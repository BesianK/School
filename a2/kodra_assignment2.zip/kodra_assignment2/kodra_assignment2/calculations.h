// Besian Kodra || ITDEV-154 || Assignment 2
#pragma once
class calculations
{
public:
	calculations();
	~calculations();
	int getMilliCount();
	int getMilliSpan(int);
	int linear();
	int number;
	int quadratic();
	void getNumber(int);
};

